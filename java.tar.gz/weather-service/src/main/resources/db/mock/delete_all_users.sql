do
$$
    BEGIN
        delete from users where 1 = 1;
        commit;
    end
$$
